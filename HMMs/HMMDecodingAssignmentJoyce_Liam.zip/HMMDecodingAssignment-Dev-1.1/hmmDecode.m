(* decode
INPUT
 - observationSeq is a list of observations, e.g., {2,3,4,1,2}
 - states is a list of the state names, e.g., {m, h}
 - alphabet is a list of the HMM alphabet, e.g., {1, 2, 3, 4}
 - emissionMatrix is a matrix of dimensions {Length[states], Length[alphabet]}.  
     emissionMatrix[[i,j]] is the probability of emitting letter j from state i, 
     e.g., {{0.4, 0.1, 0.1, 0.4}, {0.05, 0.4, 0.5, 0.05}}
 - transitionMatrix is a matrix of dimensions {Length[states], Length[states]}.
     transitionMatrix[[i, j]] is the probability of transitioning to state j on one transition starting from state i.
     e.g., {{0.99, 0.01}, {0.01, 0.99}}
 - initialStateProbs is a list of dimensions {Length[states]}
     initialStateProbs[[i]] is the prior probability that the state from which the first observations was
     emitted is state i.  
OUTPUT
- stateSeq is a list of dimensions {Length[observationSeq]}.
  stateSeq[[i]] is the ith state in the the most likely sequence of states, given the observations. 
  e.g., {h,h,m,m,m}.
  *)
decode[observationSeq_, {states_, alphabet_, emissionMatrix_, transitionMatrix_, initialStateProbs_}] := 
(*mBaseProbs and hBaseProbs are the probability of an observed base, given the state (malaria or human*)
	Module[{stateSeq={}, stateSeqNumbers={}, baseCases, viterbiCases={}, i, mBaseProbs = Map[emissionMatrix[[1,#]] &, observationSeq],
		hBaseProbs = Map[emissionMatrix[[2,#]] &, observationSeq], case={}, k, stateTraceback, delta},		
		(*define base cases for the viterbi. multiply inital state probs * the pr(obs|a certain state) to find basecases. 
			returns a list of length[states] *)
		(*take first observation, use that value to find the indicie of emissionMatrix sublist. apply to the 2nd level 
			(aka sublist) of emissionmatrix*)
		baseCases = MapThread[ #1* #2[[First[observationSeq] ]] &, {initialStateProbs, emissionMatrix}];
		viterbiCases = Append[viterbiCases, baseCases];
		(*start the counter at 2 because we already did the base case*)
		i=2;
		While[i<=Length[observationSeq], 
			(*take the last observation in viterbiCases and multiply that by the probability of changing/keeping states *)
			delta = Level[Last[viterbiCases],3] * transitionMatrix;
			(*multiply the prob of state changes to their prob of previous states. output is list with 4 elements, called "case".
			first 2 values are for state M and last two are for state H*)		
			AppendTo[case, mBaseProbs[[i]] * Max[Part[Flatten[delta], 1;;3;;2]]];
			AppendTo[case, hBaseProbs[[i]] * Max[Part[Flatten[delta], 2;;4;;2]]];
			AppendTo[viterbiCases, case];
			(*reset case so you don't get extra appends of case on case*)
			case={};
			i++;
		];	
		(*returns the sublist position of the maximum element, in the final element of the list. i.e. 1 for m and 2 for h*)
		stateSeqNumbers = Append[stateSeqNumbers, Ordering[Last[viterbiCases],-1]]; 
		For[k=1, k<Length[viterbiCases], k++,
			stateTraceback = First[Flatten[Position[viterbiCases[[k]], Max[viterbiCases[[k]] ]] ]];
			If[TrueQ[stateTraceback == 1], AppendTo[stateSeqNumbers, 1], AppendTo[stateSeqNumbers, 2]];	
		];
		(*turn the list of 1's and 2's into h's and m's*)
		stateSeq = Flatten[Map[states[[#]] &, stateSeqNumbers]];
		(*finally, return the list of h's and m's as stateSeq*)
		Return[stateSeq]
]; 

(* calculateAccuracy takes a state sequence genereted from mixed2.fa and calculates 
the number of correctly labeled states.  Note: this function only computes the
accuracy for the mixed2.fa observations.
INPUT
 - stateSeq is a list of state sequences, e.g., {h,m,h,m,m}
 OUTPUT
 - numCorrectStates = [int] number of correcly labeled states.
*)
	
calculateAccuracy[stateSeq_] := 
	Module[{keyStateSequence, numCorrectStates},
	
	keyStateSequence = Flatten[Characters[ToLowerCase[Import["mixed2key.fa"]]]];
	numCorrectStates = Count[MapThread[Equal, {stateSeq, keyStateSequence}], True]
	];

(* readHMM takes a HMM text file and outputs the state names, the alphabet
the transition matrix, and emission matrix of the HMM

INPUT
 - file is a path to an HMM file (see notebook for the format of HMM files). 

  OUTPUT
 - states = [list] list of the state names, e.g., {m, h}
 - alphabet = [list] list of the HMM alphabet, e.g., {1, 2, 3, 4}
 - emissionMatrix = [matrix of size numStates x numAlphabet] the emission matrix.  
     Element eij = the probability of state i emitting letter j., e.g., {{0.4, 0.1, 0.1, 0.4}, {0.05, 0.4, 0.5, 0.05}}
 - transitionMatrix = [matrix of size numStates x numStates] the transition matrix.
     Element tij = the probability of state i transitioning to state j, e.g., {{0.99, 0.01}, {0.01, 0.99}}

*)

(*Note: this is not exactly how I would hav written readHMM stylewise, but it works so I won't change it for now. -MRB *)

readHMM[file_] := 
	Module[{a, numStates, alphabet, numAlphabet, firstStateIndex, lastStateIndex,
		states, firstStateProbIndex, lastStateProbIndex, initialStateProbs, 
		firstEmissionIndex, lastEmissionIndex, emissionList, emissionMatrix,
		firstTransitionIndex, lastTransitionIndex, transitionList, transitionMatrix}, 
		
	a = Import[file, {"Text", "Words"}];
	
	numStates = ToExpression[a[[1]]]; (* Use ToExpression to convert from character to number *)

	alphabet = Characters[a[[2]]];
	numAlphabet = Length[alphabet];

	firstStateIndex = 3;
	lastStateIndex = firstStateIndex + numStates - 1;
	states = a[[firstStateIndex ;; lastStateIndex]];

	firstStateProbIndex = lastStateIndex + 1;
	lastStateProbIndex = firstStateProbIndex + numStates - 1;
	initialStateProbs = ToExpression[a[[firstStateProbIndex ;; lastStateProbIndex]]];

	firstEmissionIndex = lastStateProbIndex + 1;
	lastEmissionIndex = firstEmissionIndex + numStates*numAlphabet - 1;
	emissionList = ToExpression[a[[firstEmissionIndex ;; lastEmissionIndex]]];
	emissionMatrix = Partition[emissionList, numAlphabet];

	firstTransitionIndex = lastEmissionIndex + 1;
	lastTransitionIndex = firstTransitionIndex + numStates*numStates - 1;
	transitionList = ToExpression[a[[firstTransitionIndex ;; lastTransitionIndex]]];
	transitionMatrix = Partition[transitionList, numStates];
	
	{states, alphabet, emissionMatrix, transitionMatrix, initialStateProbs}

];

	
(* readFasta reads a fasta file and outputs the nucleotide sequence converted to numbers
INPUT
- fastaFile is a string representing the path to fasta file

OUTPUT
- input is a list of bases in the file indicated by fastaFile.  
  bases are translated form ACGT to 1234.
  e.g., {1,3,2,4,2}
*)
readFasta[fastaFile_]:=
	Flatten[Map[Characters, Import[fastaFile]] 
		   /. {"A"->1, "C"->2, "G"->3, "T"->4}
		   ]